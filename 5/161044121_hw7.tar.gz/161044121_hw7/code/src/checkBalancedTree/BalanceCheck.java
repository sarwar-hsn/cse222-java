package checkBalancedTree;

import balancedTrees.BinarySearchTree;
import balancedTrees.BinaryTree;

/**
 * 
 *class to check if a bst is balanced like red black / avl tree
 *
 * @param <E>
 */
public class BalanceCheck<E extends Comparable<E>> {
	
	
	/**
	 * 
	 * @param tree takes a binary search tree
	 * @return returns true if balanced like avl tree else returns false
	 */
	public boolean isAVL(BinarySearchTree<E> tree) {
		return isBalanced(tree.getRoot());
	}
	
	/**
	 * 
	 * @param node takes  a Binary tree node
	 * @return returns true if balanced else false
	 */
	private boolean isBalanced(BinaryTree.Node<E> node)
	    {
	        int lh; 
	 
	        int rh; 

	        if (node == null)
	            return true;
	        lh = height(node.left);
	        rh = height(node.right);
	 
	        if (Math.abs(lh - rh) <= 1
	            && isBalanced(node.left)
	            && isBalanced(node.right))
	            return true;
	        return false;
	    }
	
	/**
	 * 
	 * @param node takes a binary tree node
	 * @return returns a integer value
	 */
	private int height(BinaryTree.Node<E> node)
	    {
	        if (node == null)
	            return 0;
	        return 1 + Math.max(height(node.left), height(node.right));
	    }
	/**
	 * 
	 * helper class
	 *
	 */
	 class INT
	 {
	     public int d = 0;
	     INT()
	     {
	         d = 0;
	     }
	 }
	 
	 /**
	  * 
	  * @param root takes a binary tree node
	  * @param maxh takes a INT class obj
	  * @param minh takes a INT class obj
	  * @return return true or false based on balancing 
	  */
	 private boolean isBalanced(BinaryTree.Node<E> root, INT maxh, INT minh){
		 if (root == null){
		       maxh.d = minh.d = 0;
		       return true;
		   }
		 INT lmxh=new INT(), lmnh=new INT();
		 INT rmxh=new INT(), rmnh=new INT();
		 
		 if (isBalanced(root.left, lmxh, lmnh) == false)
		     return false;
		 if (isBalanced(root.right, rmxh, rmnh) == false)
		        return false;
		 maxh.d = Math.max(lmxh.d, rmxh.d) + 1;
		 minh.d = Math.min(lmnh.d, rmnh.d) + 1;
		 if (maxh.d <= 2*minh.d)
		        return true;	 
		  return false;
		 
	 }
	 
	 /**
	  * 
	  * @param tree takes a binary search tree
	  * @return returns true if the tree is balanced like red-black tree else returns false
	  */
	 public boolean isRedBlack(BinarySearchTree<E> tree) {
		 INT maxh=new INT(), minh=new INT();
		 return isBalanced(tree.getRoot(), maxh, minh);
	 }

	 
	  

}
