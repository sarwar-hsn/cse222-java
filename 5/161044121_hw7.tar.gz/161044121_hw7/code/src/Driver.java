import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;

import balancedTrees.AVLTree;
import balancedTrees.BTree;
import balancedTrees.BinarySearchTree;
import balancedTrees.RedBlackTree;
import balancedTrees.TwoThreeFourTree;
import checkBalancedTree.BalanceCheck;
import skipList.SkipList;

public class Driver {
	public static void main(String[] args) {
		System.out.println("-------part one skip list-----------------");
		{
			SkipList<Integer> x = new SkipList<>();
			x.insert(5);
			x.insert(10);
			x.insert(15);
			x.insert(30);
			x.insert(66);
			System.out.println("size before removing : " + x.getSize());
			System.out.println(x);
			x.remove(30);	
			System.out.println("size after removing : " + x.getSize());	
			System.out.println(x);
		}
		
		System.out.println("\n-------part one avl tree-----------------");
		{
			AVLTree<Integer> x = new AVLTree<>();
			x.add(5);
			x.add(10);
			x.add(15);
			x.add(30);
			x.add(66);
			System.out.println(x);
			Iterator<Integer> it = x.iterator();
			while(it.hasNext()) {
				System.out.println(it.next());
			}
			System.out.println(x.headSet(50,true));
			System.out.println(x.headSet(15));
			System.out.println(x.tailSet(15,true));
			System.out.println(x.tailSet(30));
			
		}
		
		
		System.out.println("\n------------part two----------------");
		{
			BinarySearchTree<Integer> x = new BinarySearchTree<>();
			x.add(5);
			x.add(10);
			x.add(15);
			x.add(20);
			x.add(25);
			System.out.println(x);
			BalanceCheck<Integer> isBalanced = new BalanceCheck<>();
			System.out.println("is balanced like avl : " + isBalanced.isAVL(x));
			System.out.println("is balanced like red-black tree : "+ isBalanced.isRedBlack(x));
			
			
		}
		
		
		System.out.println("\n------------part three----------------");
		{
			ArrayList<Integer> tenThousand=new ArrayList<>(10000);
			ArrayList<Integer>  twentyThousand = new ArrayList<>(20000);
			ArrayList<Integer>  fortyThousand = new ArrayList<>(40000);
			ArrayList<Integer>  eightyThousand = new ArrayList<>(80000);
			long bstTime = 0;
			long rbtTime = 0;
			long tthreeTime = 0;
			long bTreetime = 0;
			long skipListTime = 0;
			for(int i = 0 ; i < 80000; i++) {
				if(i <10000) {
					tenThousand.add(i);
				}
				if(i < 20000) {
					twentyThousand.add(i);
				}
				if (i < 40000) {
					fortyThousand.add(i);
				}
				eightyThousand.add(i);
			}
			Collections.shuffle(tenThousand);
			Collections.shuffle(twentyThousand);
			Collections.shuffle(fortyThousand);
			Collections.shuffle(eightyThousand);
			long startTime,endTime;
			
			System.out.println("------------bst-------------");
			
			//Binary Search Tree
			System.out.println("---instance one---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					bstTime+=(endTime-startTime);
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance two---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance three---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance four---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance five---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance six---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance seven---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance eight---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance nine---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			
			//Binary Search Tree
			System.out.println("---instance ten---");
			{
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (10k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();				
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (20k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (40k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
				//Binary Search Tree
				{
					BinarySearchTree<Integer> x = new BinarySearchTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for bst (80k) :\t"+(endTime - startTime));
					bstTime+=(endTime-startTime);
				}
				
			}
			System.out.println("\n------------red black tree---------------");
			
			//Red Black Tree
			System.out.println("---instance one---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance two---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			
			System.out.println("---instance three---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance four---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance five---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance six---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance seven---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance eight---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance nine---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			System.out.println("---instance ten---");
			{
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (10k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (20k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (40k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
				{
					RedBlackTree<Integer> x = new RedBlackTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for red-black tree (80k) :\t"+(endTime - startTime));
					rbtTime+=(endTime-startTime);
				}
				
			}
			
			
			System.out.println("---------------2-3 tree------------------");
			System.out.println("---instance one---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance two---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance three---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance four---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance five---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance six---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance seven---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance eight---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance nine---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("---instance ten---");
			{
				//2-3 tree
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.add(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (10k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.add(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (20k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.add(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (40k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
				{
					TwoThreeFourTree<Integer> x = new TwoThreeFourTree<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.add(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.add((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for 2-3 tree (80k) :\t"+(endTime - startTime));
					tthreeTime += (endTime - startTime);
				}
			}
			
			System.out.println("------------------BTree--------------");
			
			System.out.println("---instance one---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance two---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance three---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance four---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance five---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance six---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance seven---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance eight---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance nine---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			System.out.println("---instance ten---");
			{
				//Btree
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (10k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (20k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (40k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				{
					BTree<Integer> x = new BTree<>(5);
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for btree (80k) :\t"+(endTime - startTime));
					bTreetime+=(endTime - startTime);
				}
				
				
			}
			
			
			System.out.println("--------------skip list--------------");
			
			System.out.println("--- instance one ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance two ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance three ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance four ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance five ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance six ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			
			System.out.println("--- instance seven ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance eight ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance nine ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println("--- instance ten ---");
			{
				//skip list
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < tenThousand.size();i++) {
						x.insert(tenThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(10k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < twentyThousand.size();i++) {
						x.insert(twentyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(20k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < fortyThousand.size();i++) {
						x.insert(fortyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(40k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
				{
					SkipList<Integer> x = new SkipList<>();
					for(int i = 0 ; i < eightyThousand.size();i++) {
						x.insert(eightyThousand.get(i));
					}
					startTime = System.nanoTime();
					for(int i = 0 ; i < 100; i++) {
						x.insert((int)Math.random());
					}
					endTime = System.nanoTime();
					System.out.println("elapsed time in nanosec for skip list(80k) :\t"+(endTime - startTime));
					skipListTime+=(endTime - startTime);
				}
			}
			
			System.out.println();
			System.out.println("average for bst in nano sec  : "+ bstTime/40);
			System.out.println("average for red black tree in nano sec  : "+ rbtTime/40);
			System.out.println("average for two three tree in nano sec  : "+ tthreeTime/40);
			System.out.println("average for btree  in nano sec  : "+ bTreetime/40);
			System.out.println("average for skip list in nano sec  : "+ skipListTime/40);
			
			
			System.out.println("\nfrom the average runtime it's obvious that,");
			System.out.println("btree(5 node) , bst and 2-3 performs less than skip list and red-black tree.");
			System.out.println("skip list has the best runtime almost most of the cases");
			
		}
		
		
	}
}
	